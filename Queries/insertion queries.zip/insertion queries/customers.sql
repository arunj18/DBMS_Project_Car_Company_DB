-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 19, 2017 at 10:56 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `Name` varchar(30) DEFAULT NULL,
  `Contact_No` varchar(15) DEFAULT NULL,
  `Address` varchar(100) DEFAULT NULL,
  `Ord_id` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`Name`, `Contact_No`, `Address`, `Ord_id`) VALUES
('Theresa', '86-(562)735-912', '7125 Orin Junction', '117-66-464'),
('Jesse', '86-(268)194-656', '7 Hintze Court', '138-02-541'),
('Roger', '81-(103)113-444', '758 Mariners Cove Junction', '141-64-197'),
('Phyllis', '62-(849)427-378', '7737 Grayhawk Park', '213-98-019'),
('Roy', '56-(301)533-409', '0 Derek Point', '224-95-547'),
('Julie', '55-(786)356-471', '68 Mandrake Court', '252-81-655'),
('Andrea', '30-(593)578-993', '47 Hanover Center', '314-32-645'),
('Kevin', '86-(468)678-513', '956 Paget Lane', '344-65-398'),
('Daniel', '47-(183)242-358', '00 Loeprich Drive', '406-95-378'),
('John', '86-(139)660-098', '4 Grover Hill', '442-57-845'),
('Debra Ray', '86-(562)751-890', '99 Queens Borrow', '444-44-444'),
('Rachel', '502-(795)368-34', '4 Towne Center', '488-41-547'),
('Carlos', '62-(336)137-929', '75674 Nova Road', '539-78-539'),
('Ernest Coleman', '86-(562)755-900', '12 Brooke Street', '555-55-555'),
('Theresa', '86-(302)879-627', '77 Ronald Regan Center', '566-52-246'),
('Pamela', '963-(243)170-08', '2222 Toban Hill', '590-92-976'),
('Johnny', '86-(719)256-641', '03184 Debra Alley', '595-25-214'),
('Beverly', '234-(515)632-30', '644 Maryland Pass', '596-09-068'),
('Eric', '212-(597)111-15', '82 Arkansas Court', '600-28-782'),
('Howard', '242-(852)691-37', '8 Golf Course Road', '650-82-103'),
('Evelyn', '30-(159)423-032', '891 Morningstar Center', '654-76-929'),
('Willie', '81-(557)380-225', '80164 Darwin Pass', '693-49-928'),
('Daniel', '420-(817)407-45', '41 Del Sol Alley', '730-50-138'),
('Andrew', '234-(769)326-52', '02048 Blue Bill Park Place', '733-58-084'),
('Linda', '86-(399)803-591', '85185 Maple Wood Alley', '762-10-097'),
('Ernest', '46-(900)505-293', '095 Manufacturers Avenue', '795-96-952'),
('Cynthia', '55-(188)149-747', '8083 Vidon Drive', '860-64-623'),
('Marie', '972-(421)799-75', '58813 Lunder Street', '865-71-986'),
('Judy', '48-(967)975-212', '39 Basil Hill', '925-70-970');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`Ord_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `customers`
--
ALTER TABLE `customers`
  ADD CONSTRAINT `customers_ibfk_1` FOREIGN KEY (`Ord_id`) REFERENCES `orders` (`Ord_ID`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
