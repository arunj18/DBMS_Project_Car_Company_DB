-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 19, 2017 at 10:57 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `orderplaced`
--

CREATE TABLE `orderplaced` (
  `Ord_id` varchar(10) NOT NULL,
  `B_id` varchar(10) NOT NULL,
  `Offer_id` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orderplaced`
--

INSERT INTO `orderplaced` (`Ord_id`, `B_id`, `Offer_id`) VALUES
('138-02-541', '841497AB ', 'BOKHG-37'),
('590-92-976', '296248AY ', 'BQHGN-61'),
('406-95-378', '485731FX ', 'CMBEZ-42'),
('730-50-138', '762047KW ', 'DQAIB-50'),
('117-66-464', '151970RQ ', 'DYJVA-65'),
('444-44-444', '841497AB', 'EMP-DIS-01'),
('555-55-555', '841497AB', 'EMP-DIS-01'),
('733-58-084', '129014SG ', 'EPHCG-52'),
('860-64-623', '344137LC ', 'FEPAB-72'),
('865-71-986', '513411HD ', 'ILREJ-74'),
('795-96-952', '239897CT ', 'IVMAL-71'),
('488-41-547', '848897IT ', 'KMQIT-23'),
('762-10-097', '076199PZ ', 'KPCAH-35'),
('596-09-068', '229485NX ', 'KXTBD-27'),
('650-82-103', '597848HD ', 'MLQNB-05'),
('213-98-019', '649859NJ ', 'NMPGC-25'),
('224-95-547', '144872OS ', 'NWLPD-03'),
('252-81-655', '081730GV ', 'OCFXQ-02'),
('539-78-539', '597388RE ', 'PIUDT-29'),
('693-49-928', '054758ZL ', 'PJNOV-07'),
('595-25-214', '446747ZH ', 'QDECI-51'),
('442-57-845', '987583RH ', 'QWSIG-28'),
('566-52-246', '580353QC ', 'TGBAL-80'),
('600-28-782', '722184CJ ', 'UMHLN-93'),
('344-65-398', '424680QU ', 'VBMAW-65'),
('925-70-970', '086456BX ', 'VJSFC-15'),
('141-64-197', '666060HY ', 'VSLEK-62'),
('654-76-929', '266610GR ', 'XZLHK-80'),
('314-32-645', '217070XS ', 'ZLGWY-90');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orderplaced`
--
ALTER TABLE `orderplaced`
  ADD PRIMARY KEY (`Ord_id`,`B_id`),
  ADD KEY `B_id` (`B_id`),
  ADD KEY `Offer_id` (`Offer_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orderplaced`
--
ALTER TABLE `orderplaced`
  ADD CONSTRAINT `orderplaced_ibfk_1` FOREIGN KEY (`Ord_id`) REFERENCES `orders` (`Ord_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `orderplaced_ibfk_2` FOREIGN KEY (`B_id`) REFERENCES `branches` (`Branch_ID`),
  ADD CONSTRAINT `orderplaced_ibfk_3` FOREIGN KEY (`Offer_id`) REFERENCES `offers` (`Offer_ID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
