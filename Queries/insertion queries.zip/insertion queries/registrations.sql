-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 19, 2017 at 10:57 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `registrations`
--

CREATE TABLE `registrations` (
  `Reg_ID` varchar(15) NOT NULL,
  `License_no` varchar(15) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registrations`
--

INSERT INTO `registrations` (`Reg_ID`, `License_no`, `name`) VALUES
('00-8478408', '58118-0037', 'Tina'),
('01-8822151', '76237-135', 'Thomas'),
('06-6237986', '53942-318', 'Joyce'),
('09-4606495', '50436-0124', 'Brian'),
('11-5757123', '65044-1788', 'Anna'),
('14-2361483', '55289-708', 'Willie'),
('19-3266031', '76237-108', 'Jimmy'),
('19-5952175', '57955-0288', 'Janice'),
('19-6975641', '61314-206', 'Annie'),
('20-4243087', '35356-448', 'Joan'),
('20-9267541', '61589-6006', 'Daniel'),
('21-3441950', '0093-4822', 'Joshua'),
('27-6311596', '50436-0324', 'Kevin'),
('28-4376900', '64760-202', 'Bobby'),
('33-6217391', '47682-007', 'Jane'),
('33-6422304', '54868-3363', 'Frances'),
('47-6017088', '52125-150', 'Marilyn'),
('53-8555830', '62011-0169', 'Diana'),
('57-9120621', '61589-5312', 'Jennifer'),
('59-4484589', '24882-325', 'Kathryn'),
('61-0250241', '12546-111', 'Donald'),
('75-0015875', '60215-412', 'Kathryn'),
('76-6843396', '17478-544', 'Albert'),
('81-0254325', '65923-011', 'Wanda'),
('82-6219806', '37000-158', 'Todd'),
('86-8256465', '42998-303', 'Wayne'),
('87-1271338', '37000-714', 'Walter'),
('88-0360614', '68094-586', 'Anna'),
('97-3614676', '0143-1480', 'Gary'),
('99-4949217', '68382-133', 'Howard');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `registrations`
--
ALTER TABLE `registrations`
  ADD PRIMARY KEY (`Reg_ID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
