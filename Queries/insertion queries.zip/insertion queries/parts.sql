-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 19, 2017 at 10:57 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `parts`
--

CREATE TABLE `parts` (
  `Part_No` varchar(15) NOT NULL,
  `PName` varchar(20) DEFAULT NULL,
  `Type` varchar(20) DEFAULT NULL,
  `Material` varchar(20) DEFAULT NULL,
  `Model_no` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `parts`
--

INSERT INTO `parts` (`Part_No`, `PName`, `Type`, `Material`, `Model_no`) VALUES
('CP-8077', 'Player', 'Necessary', 'HGC', 'PYDI-9964'),
('DI-8111', 'Cover', 'Optional', 'Carbon Fibre', 'XZWJ-1410'),
('FY-9506', 'Mirror', 'Optional', 'HGC', 'AVNH-8985'),
('GP-5439', 'Player', 'Optional', 'Carbon Fibre', 'TREP-0192'),
('HI-9203', 'Cover', 'Optional', 'Steel', 'KZIQ-9265'),
('JS-8807', 'Mirror', 'Necessary', 'HGC', 'XZWJ-1410'),
('JV-6527', 'Player', 'Recommended', 'HGC', 'LZQX-3552'),
('KB-0335', 'Mirror', 'Necessary', 'Carbon Fibre', 'WNBO-1882'),
('KR-0055', 'Player', 'Optional', 'Carbon Fibre', 'CTJS-9892'),
('LZ-9590', 'Player', 'Necessary', 'HGC', 'BOAV-8829'),
('MC-9183', 'Cover', 'Optional', 'Leather', 'ENTP-0787'),
('MK-4134', 'Mirror', 'Recommended', 'HGC', 'UACY-8948'),
('NI-8790', 'Player', 'Recommended', 'Carbon Fibre', 'KEWN-2931'),
('NX-6540', 'Mirror', 'Recommended', 'Leather', 'CTJS-9892'),
('OB-1392', 'Mirror', 'Optional', 'Carbon Fibre', 'RPYE-9436'),
('OF-5219', 'Player', 'Recommended', 'HGC', 'RDTC-7292'),
('OP-0438', 'Mirror', 'Optional', 'HGC', 'WNBO-1882'),
('OX-3847', 'Player', 'Necessary', 'Carbon Fibre', 'FWDG-7173'),
('OZ-8661', 'Mirror', 'Optional', 'Steel', 'ENTP-0787'),
('PG-4523', 'Mirror', 'Optional', 'HGC', 'FMLC-1591'),
('PX-9296', 'Player', 'Optional', 'Leather', 'DLAW-8848'),
('PY-4049', 'Cover', 'Necessary', 'Leather', 'NEJA-5842'),
('QG-4315', 'Player', 'Recommended', 'Steel', 'ENTP-0787'),
('UH-9707', 'Cover', 'Optional', 'HGC', 'UONZ-9118'),
('VF-4508', 'Player', 'Recommended', 'HGC', 'ENTP-0787'),
('VH-8590', 'Player', 'Necessary', 'HGC', 'RPYE-9436'),
('XK-0367', 'Cover', 'Optional', 'Steel', 'IQPT-7636'),
('YB-9693', 'Player', 'Recommended', 'Steel', 'WNBO-1882'),
('YM-4161', 'Cover', 'Recommended', 'HGC', 'DLAW-8848'),
('ZO-3184', 'Cover', 'Recommended', 'HGC', 'RPYE-9436');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `parts`
--
ALTER TABLE `parts`
  ADD PRIMARY KEY (`Part_No`),
  ADD KEY `Model_no` (`Model_no`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `parts`
--
ALTER TABLE `parts`
  ADD CONSTRAINT `parts_ibfk_1` FOREIGN KEY (`Model_no`) REFERENCES `vehicles` (`Model_No`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
