-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 19, 2017 at 10:57 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `Ord_ID` varchar(10) NOT NULL,
  `type` varchar(15) DEFAULT NULL,
  `Ord_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`Ord_ID`, `type`, `Ord_date`) VALUES
('117-66-464', 'Individual', '0000-00-00'),
('138-02-541', 'Corporate', '0000-00-00'),
('141-64-197', 'Corporate', '2016-10-18'),
('213-98-019', 'Individual', '0000-00-00'),
('224-95-547', 'Individual', '0000-00-00'),
('252-81-655', 'Individual', '0000-00-00'),
('314-32-645', 'Corporate', '2017-02-22'),
('344-65-398', 'Government', '0000-00-00'),
('406-95-378', 'Corporate', '0000-00-00'),
('442-57-845', 'Corporate', '0000-00-00'),
('444-44-444', 'Individual', '2017-04-02'),
('488-41-547', 'Government', '0000-00-00'),
('539-78-539', 'Government', '0000-00-00'),
('555-55-555', 'Individual', '2017-04-01'),
('566-52-246', 'Government', '0000-00-00'),
('590-92-976', 'Corporate', '0000-00-00'),
('595-25-214', 'Government', '0000-00-00'),
('596-09-068', 'Individual', '0000-00-00'),
('600-28-782', 'Government', '0000-00-00'),
('650-82-103', 'Government', '0000-00-00'),
('654-76-929', 'Corporate', '0000-00-00'),
('693-49-928', 'Individual', '0000-00-00'),
('730-50-138', 'Corporate', '0000-00-00'),
('733-58-084', 'Corporate', '0000-00-00'),
('762-10-097', 'Government', '0000-00-00'),
('795-96-952', 'Corporate', '0000-00-00'),
('860-64-623', 'Government', '0000-00-00'),
('865-71-986', 'Government', '0000-00-00'),
('925-70-970', 'Corporate', '0000-00-00'),
('999-99-999', 'Corporate', '2016-05-15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`Ord_ID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
