-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 19, 2017 at 10:55 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `branches`
--

CREATE TABLE `branches` (
  `Branch_ID` varchar(10) NOT NULL,
  `BName` varchar(20) DEFAULT NULL,
  `Location` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `branches`
--

INSERT INTO `branches` (`Branch_ID`, `BName`, `Location`) VALUES
('054758ZL ', 'FCE-wqcef', 'Kochi'),
('076199PZ ', 'XNJ-zchwr', 'Bangalore'),
('081730GV ', 'XUO-nbetk', 'Mumbai'),
('086456BX ', 'PUT-utxqs', 'Mumbai'),
('129014SG ', 'BQZ-pjdxe', 'Bhopal'),
('144872OS ', 'EJL-hpock', 'Bhopal'),
('151970RQ ', 'IMJ-atejw', 'Kochi'),
('159083EN ', 'WBQ-aucvo', 'Hyderabad'),
('217070XS ', 'ACJ-pkczv', 'Chennai'),
('229485NX ', 'WIM-vetbd', 'Delhi'),
('239897CT ', 'GIM-xiulr', 'Hyderabad'),
('266610GR ', 'UQJ-zpijd', 'Hyderabad'),
('296248AY ', 'KBH-lxzvm', 'Bangalore'),
('344137LC ', 'YGZ-msnoz', 'Bangalore'),
('349010QS ', 'FEI-tzhiy', 'Bhopal'),
('424680QU ', 'URK-okwvt', 'Bangalore'),
('446747ZH ', 'ZIK-eqmgx', 'Chennai'),
('485731FX ', 'GDL-kmlzr', 'Bangalore'),
('513411HD ', 'GCK-hqbso', 'Delhi'),
('580353QC ', 'CNO-gtmci', 'Mumbai'),
('597388RE ', 'VGU-bovul', 'Delhi'),
('597848HD ', 'MBU-lmyce', 'Kochi'),
('649859NJ ', 'GKY-zgnfc', 'Kochi'),
('666060HY ', 'IZA-xrljg', 'Chennai'),
('722184CJ ', 'UBQ-wzjrn', 'Bangalore'),
('762047KW ', 'QUZ-ktmjo', 'Hyderabad'),
('841497AB ', 'WYD-ntcur', 'Mysore'),
('848897IT ', 'WJK-gjmcd', 'Delhi'),
('857305RI ', 'NGE-fmytc', 'Bhopal'),
('987583RH ', 'WSM-xgsuv', 'Kochi');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `branches`
--
ALTER TABLE `branches`
  ADD PRIMARY KEY (`Branch_ID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
