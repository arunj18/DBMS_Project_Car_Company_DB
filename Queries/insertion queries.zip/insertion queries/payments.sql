-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 19, 2017 at 10:57 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `Pay_ID` varchar(10) NOT NULL,
  `Amount` decimal(15,2) DEFAULT NULL,
  `Ins_id` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`Pay_ID`, `Amount`, `Ins_id`) VALUES
('05-DWOL-00', '235431.77', '4800FLVBO0'),
('05-XEBQ-15', '628881.91', '6144ECXOI6'),
('06-ESNC-19', '607672.82', '6450MTKZF3'),
('11-XCYR-92', '121644.25', '9973RNHSF4'),
('16-BVLC-24', '893590.13', '7204TFJDS0'),
('20-PHXE-64', '130714.61', '7463MDFXQ9'),
('23-WAGK-28', '536774.36', '8890ASDWH3'),
('24-RHPE-18', '740949.77', '7204TFJDS0'),
('27-LHSU-58', '260998.96', '0010IMWJX4'),
('29-HPFA-82', '859997.40', '7463MDFXQ9'),
('29-ZROG-90', '332426.13', '1033WRPMY1'),
('32-GWHV-14', '579256.66', '7463MDFXQ9'),
('35-KCEI-65', '954555.36', '1033WRPMY1'),
('38-XUIC-45', '4851.33', '1033WRPMY1'),
('40-HBYL-14', '773333.69', '7463MDFXQ9'),
('43-NQMH-45', '380507.67', '7408WBEMI7'),
('43-RNEP-56', '245562.34', '0010IMWJX4'),
('45-FIDT-73', '155034.96', '8449KZASY6'),
('49-GLUQ-63', '849323.46', '4643FWOME6'),
('50-UTVJ-66', '457742.89', '4800FLVBO0'),
('63-UKHL-01', '64987.06', '9930UWVXB3'),
('65-VSAR-88', '613931.12', '1033WRPMY1'),
('72-HPSV-38', '127023.04', '5814HZRNK3'),
('73-VCPX-55', '310501.78', '9973RNHSF4'),
('75-PFLH-31', '292688.50', '0241ODIPC7'),
('76-ZYQJ-21', '408072.95', '9973RNHSF4'),
('84-JCQF-50', '370038.22', '4352WAENB4'),
('93-IVNQ-12', '168476.04', '7408WBEMI7'),
('95-TSDU-09', '62583.45', '8449KZASY6'),
('97-IKPH-07', '167013.42', '5814HZRNK3');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`Pay_ID`),
  ADD KEY `Ins_id` (`Ins_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`Ins_id`) REFERENCES `insurance` (`Ins_ID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
