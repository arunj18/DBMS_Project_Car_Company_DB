-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 19, 2017 at 10:56 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `needs`
--

CREATE TABLE `needs` (
  `Model_no` varchar(15) NOT NULL,
  `Part_no` varchar(15) NOT NULL,
  `Supplier_id` varchar(10) NOT NULL,
  `Quantity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `needs`
--

INSERT INTO `needs` (`Model_no`, `Part_no`, `Supplier_id`, `Quantity`) VALUES
('AVNH-8985', 'OZ-8661', 'WQRAI-22', 14),
('AVNH-8985', 'ZO-3184', 'HEDUZ-45', 5),
('BOAV-8829', 'NX-6540', 'EKZQA-94', 14),
('CTJS-9892', 'JS-8807', 'WQRAI-22', 11),
('DYKG-0889', 'JV-6527', 'HEDUZ-45', 11),
('DYKG-0889', 'MC-9183', 'UTBAV-96', 9),
('DYKG-0889', 'YB-9693', 'WKOUG-24', 20),
('ENTP-0787', 'NI-8790', 'ROZNV-18', 2),
('FWDG-7173', 'JV-6527', 'ZTHWK-31', 16),
('HNVZ-6614', 'NI-8790', 'EKZQA-94', 20),
('HNVZ-6614', 'ZO-3184', 'VNJER-18', 17),
('KSEM-6198', 'OB-1392', 'PFEXH-85', 11),
('KSEM-6198', 'XK-0367', 'YWHTG-90', 15),
('KSEM-6198', 'YM-4161', 'VFBSA-78', 3),
('KZIQ-9265', 'MK-4134', 'WQRAI-22', 16),
('LVEU-0143', 'PG-4523', 'CUBIM-05', 16),
('LZQX-3552', 'VH-8590', 'WKOUG-24', 13),
('PYDI-9964', 'JS-8807', 'AFKIN-22', 13),
('QAEK-8835', 'GP-5439', 'VFBSA-78', 18),
('QAEK-8835', 'PX-9296', 'XATCJ-80', 4),
('QDKF-9648', 'ZO-3184', 'PFEXH-85', 19),
('RPYE-9436', 'DI-8111', 'RVICO-71', 5),
('UONZ-9118', 'KR-0055', 'HEDUZ-45', 14),
('UONZ-9118', 'ZO-3184', 'UTBAV-96', 15),
('VUIG-8432', 'MC-9183', 'HBDSJ-62', 1),
('VUIG-8432', 'VF-4508', 'AFKIN-22', 3),
('WNBO-1882', 'MC-9183', 'WXHOE-97', 8),
('XCDF-1473', 'VH-8590', 'YWHTG-90', 14),
('XZWJ-1410', 'PX-9296', 'WXHOE-97', 17),
('XZWJ-1410', 'ZO-3184', 'VFBSA-78', 10);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `needs`
--
ALTER TABLE `needs`
  ADD PRIMARY KEY (`Model_no`,`Part_no`,`Supplier_id`),
  ADD KEY `Part_no` (`Part_no`),
  ADD KEY `Supplier_id` (`Supplier_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `needs`
--
ALTER TABLE `needs`
  ADD CONSTRAINT `needs_ibfk_1` FOREIGN KEY (`Model_no`) REFERENCES `vehicles` (`Model_No`),
  ADD CONSTRAINT `needs_ibfk_2` FOREIGN KEY (`Part_no`) REFERENCES `parts` (`Part_No`),
  ADD CONSTRAINT `needs_ibfk_3` FOREIGN KEY (`Supplier_id`) REFERENCES `suppliers` (`Supplier_ID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
