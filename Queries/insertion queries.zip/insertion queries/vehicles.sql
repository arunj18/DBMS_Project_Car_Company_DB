-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 19, 2017 at 10:57 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `vehicles`
--

CREATE TABLE `vehicles` (
  `Model_No` varchar(15) NOT NULL,
  `Type` varchar(20) DEFAULT NULL,
  `Ord_id` varchar(10) DEFAULT NULL,
  `Std_id` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vehicles`
--

INSERT INTO `vehicles` (`Model_No`, `Type`, `Ord_id`, `Std_id`) VALUES
('AVNH-8985', 'SUV', NULL, '500989'),
('BOAV-8829', '6W', '138-02-541', '80396'),
('CTJS-9892', 'Sedan', '539-78-539', '263993'),
('DDES-0832', 'Sedan', NULL, '414118'),
('DLAW-8848', 'Sedan', '314-32-645', '558911'),
('DYKG-0889', '6W', '693-49-928', '405156'),
('ENTP-0787', 'MUV', '406-95-378', '905395'),
('FMLC-1591', '8W', '224-95-547', '414118'),
('FWDG-7173', '6W', '442-57-845', '960866'),
('HNVZ-6614', '6W', '566-52-246', '905395'),
('IQPT-7636', 'Hatchback', '590-92-976', '80396'),
('KEWN-2931', 'SUV', '860-64-623', '984892'),
('KSEM-6198', 'MUV', '654-76-929', '414118'),
('KZIQ-9265', '8W', NULL, '224095'),
('LVEU-0143', '8W', '213-98-019', '734672'),
('LZQX-3552', 'MUV', '595-25-214', '297053'),
('NEJA-5842', '6W', '117-66-464', '577599'),
('PSWQ-0852', 'Sedan', NULL, '414118'),
('PYDI-9964', 'Hatchback', '865-71-986', '870877'),
('QAEK-8835', 'MUV', '600-28-782', '149128'),
('QDKF-9648', '6W', '730-50-138', '537650'),
('QGBI-6049', '6W', '596-09-068', '500989'),
('RDTC-7292', 'Sedan', '141-64-197', '961323'),
('RPYE-9436', 'MUV', '344-65-398', '224095'),
('TREP-0192', 'MUV', '488-41-547', '984892'),
('TUWH-8279', '8W', '650-82-103', '80396'),
('UACY-8948', 'SUV', NULL, '414118'),
('UONZ-9118', '6W', '925-70-970', '617567'),
('VUIG-8432', 'SUV', '733-58-084', '500989'),
('WNBO-1882', 'MUV', '795-96-952', '961323'),
('XCDF-1473', '8W', '252-81-655', '645904'),
('XZWJ-1410', 'Hatchback', '762-10-097', '80396');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `vehicles`
--
ALTER TABLE `vehicles`
  ADD PRIMARY KEY (`Model_No`),
  ADD KEY `Std_id` (`Std_id`),
  ADD KEY `vehicles_ibfk_1` (`Ord_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `vehicles`
--
ALTER TABLE `vehicles`
  ADD CONSTRAINT `vehicles_ibfk_1` FOREIGN KEY (`Ord_id`) REFERENCES `orders` (`Ord_ID`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `vehicles_ibfk_2` FOREIGN KEY (`Std_id`) REFERENCES `standards` (`Std_No`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
