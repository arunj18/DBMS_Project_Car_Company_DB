-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 19, 2017 at 10:56 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `dependants`
--

CREATE TABLE `dependants` (
  `Name` varchar(30) DEFAULT NULL,
  `Age` int(11) DEFAULT NULL,
  `Sex` varchar(2) DEFAULT NULL,
  `Emp_id` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dependants`
--

INSERT INTO `dependants` (`Name`, `Age`, `Sex`, `Emp_id`) VALUES
('Phyllis Griffin', 46, 'F', '01-1621895'),
('Deborah Dixon', 14, 'F', '08-8222536'),
('Billy Montgomery', 5, 'M', '13-0240506'),
('Susan Berry', 67, 'F', '14-6553540'),
('Alice Palmer', 28, 'F', '26-5828455'),
('Alice Mitchell', 59, 'F', '27-6855610'),
('Justin Taylor', 57, 'M', '43-4840454'),
('Adam Bishop', 57, 'M', '48-5703738'),
('Brenda Washington', 32, 'F', '52-3293793'),
('George Smith', 38, 'M', '54-1793149'),
('Christopher Butler', 43, 'M', '69-0351359'),
('Rebecca Patterson', 10, 'F', '75-5559731'),
('Robert Franklin', 91, 'M', '80-8629034'),
('Rachel Thompson', 80, 'F', '82-8731919'),
('Gary Vasquez', 48, 'M', '85-7613819'),
('Wayne Lawrence', 86, 'M', '86-0723406'),
('Charles Cole', 48, 'M', '86-8296653'),
('Katherine Mcdonald', 11, 'F', '90-6092315'),
('Emily Hanson', 16, 'F', '97-5740333');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dependants`
--
ALTER TABLE `dependants`
  ADD PRIMARY KEY (`Emp_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `dependants`
--
ALTER TABLE `dependants`
  ADD CONSTRAINT `dependants_ibfk_1` FOREIGN KEY (`Emp_id`) REFERENCES `employees` (`Emp_ID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
