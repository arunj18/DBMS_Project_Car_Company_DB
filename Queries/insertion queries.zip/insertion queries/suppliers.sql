-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 19, 2017 at 10:57 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `Supplier_ID` varchar(10) NOT NULL,
  `SName` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`Supplier_ID`, `SName`) VALUES
('AFKIN-22', 'Watsica-Bashirian'),
('BISFP-71', 'Fahey, Blanda and Anderson'),
('CUBIM-05', 'Rosenbaum, Parker and Reynolds'),
('DPNOF-48', 'Kohler, Hammes and Hermann'),
('EGCRH-82', 'Little Group'),
('EKZQA-94', 'Zulauf-Roberts'),
('GIJYT-85', 'King Inc'),
('GVCLU-73', 'Haley-Terry'),
('HBDSJ-62', 'Bahringer, Funk and Morar'),
('HEDUZ-45', 'Walter and Sons'),
('JABMR-10', 'McDermott, Dickinson and Herma'),
('LEBFP-76', 'Eichmann LLC'),
('LWNCR-26', 'Mayert-Tromp'),
('MBGWA-10', 'Romaguera Inc'),
('PFEXH-85', 'Murray, Aufderhar and Lemke'),
('QXCUW-52', 'Rippin Group'),
('RHVFT-16', 'Zemlak, Wintheiser and Deckow'),
('ROZNV-18', 'Konopelski, Kling and Dibbert'),
('RVICO-71', 'Cruickshank LLC'),
('UCFOI-59', 'Farrell, Green and Wuckert'),
('UTBAV-96', 'Howell Inc'),
('VFBSA-78', 'Steuber Inc'),
('VNJER-18', 'Rodriguez-Mayer'),
('WKOUG-24', 'Dickens-Schuster'),
('WQRAI-22', 'Hirthe, Muller and Hettinger'),
('WXHOE-97', 'Johnson, Herman and Wisoky'),
('XATCJ-80', 'Hauck and Sons'),
('YWHTG-90', 'Morissette Inc'),
('ZBGES-42', 'Lang-Harvey'),
('ZTHWK-31', 'Osinski-Olson');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`Supplier_ID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
