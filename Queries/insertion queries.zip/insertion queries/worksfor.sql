-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 19, 2017 at 10:58 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `worksfor`
--

CREATE TABLE `worksfor` (
  `Emp_id` varchar(10) DEFAULT NULL,
  `Dept_id` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `worksfor`
--

INSERT INTO `worksfor` (`Emp_id`, `Dept_id`) VALUES
('27-6855610', '526'),
('13-0240506', '863'),
('08-8222536', '863'),
('86-8296653', '272'),
('43-4840454', '272'),
('15-7462614', '561'),
('82-8731919', '561'),
('73-1773331', '561'),
('37-3649038', '272'),
('14-6553540', '561'),
('75-5559731', '609'),
('76-0417447', '609'),
('85-8814473', '482'),
('59-0263963', '561'),
('85-7613819', '272'),
('54-1793149', '272'),
('69-0351359', '482'),
('02-7723689', '863'),
('06-6459196', '561'),
('12-7316267', '526'),
('90-6092315', '482'),
('52-3293793', '561'),
('86-0723406', '272'),
('17-3387637', '482'),
('26-5828455', '561'),
('97-5740333', '863'),
('80-8629034', '272'),
('01-1621895', '526'),
('48-5703738', '609'),
('85-3080139', '561');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `worksfor`
--
ALTER TABLE `worksfor`
  ADD KEY `Dept_id` (`Dept_id`),
  ADD KEY `Emp_id` (`Emp_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `worksfor`
--
ALTER TABLE `worksfor`
  ADD CONSTRAINT `worksfor_ibfk_1` FOREIGN KEY (`Dept_id`) REFERENCES `departments` (`Dept_No`),
  ADD CONSTRAINT `worksfor_ibfk_2` FOREIGN KEY (`Emp_id`) REFERENCES `employees` (`Emp_ID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
