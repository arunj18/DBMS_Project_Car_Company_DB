-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 19, 2017 at 10:56 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `Emp_ID` varchar(10) NOT NULL,
  `EName` varchar(30) DEFAULT NULL,
  `Salary` decimal(10,0) DEFAULT NULL,
  `Start_date` date DEFAULT NULL,
  `B_id` varchar(10) DEFAULT NULL,
  `Mng_ID` varchar(10) DEFAULT NULL,
  `Dept_id` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`Emp_ID`, `EName`, `Salary`, `Start_date`, `B_id`, `Mng_ID`, `Dept_id`) VALUES
('01-1621895', 'Ernest Coleman', '9965212', '0000-00-00', '144872OS ', '', '482'),
('02-7723689', 'Debra Ray', '3800669', '0000-00-00', '513411HD ', '', '561'),
('06-6459196', 'Daniel Sanchez', '1699049', '0000-00-00', '424680QU ', '69-0351359', '863'),
('08-8222536', 'Alice Reyes', '5252659', '0000-00-00', '217070XS ', '01-1621895', '482'),
('12-7316267', 'Marie Lane', '7253900', '0000-00-00', '086456BX ', '59-0263963', '526'),
('13-0240506', 'Roger Gray', '1733867', '0000-00-00', '649859NJ ', '17-3387637', '609'),
('14-6553540', 'Tammy Harrison', '4003954', '0000-00-00', '296248AY ', '12-7316267', '272'),
('15-7462614', 'Gerald Hamilton', '3538723', '0000-00-00', '597388RE ', '', '609'),
('17-3387637', 'Samuel Martinez', '302250', '0000-00-00', '848897IT ', '02-7723689', '561'),
('26-5828455', 'Kathy Gordon', '9030925', '0000-00-00', '649859NJ ', '14-6553540', '561'),
('27-6855610', 'Philip Garza', '8997762', '0000-00-00', '841497AB ', '08-8222536', '482'),
('37-3649038', 'Raymond Harper', '5736629', '0000-00-00', '229485NX ', '', '863'),
('43-4840454', 'Craig Matthews', '6020335', '0000-00-00', '296248AY ', '17-3387637', '561'),
('48-5703738', 'Michelle Meyer', '6700655', '0000-00-00', '054758ZL ', '85-8814473', '526'),
('52-3293793', 'Annie Gutierrez', '4763172', '0000-00-00', '076199PZ ', '90-6092315', '609'),
('54-1793149', 'Alice Rivera', '6690668', '0000-00-00', '296248AY ', '52-3293793', '561'),
('59-0263963', 'Amy Patterson', '9510066', '0000-00-00', '151970RQ ', '', '526'),
('69-0351359', 'Jesse Montgomery', '3206106', '0000-00-00', '151970RQ ', '97-5740333', '526'),
('73-1773331', 'Mildred Hall', '1342193', '0000-00-00', '239897CT ', '15-7462614', '609'),
('75-5559731', 'Catherine Marshall', '6022294', '0000-00-00', '266610GR ', '17-3387637', '482'),
('76-0417447', 'Joan Allen', '6796562', '0000-00-00', '144872OS ', '', '482'),
('80-8629034', 'Teresa Mendoza', '2567405', '0000-00-00', '513411HD ', '54-1793149', '526'),
('82-8731919', 'Nicholas Bishop', '7773899', '0000-00-00', '513411HD ', '08-8222536', '526'),
('85-3080139', 'Alice Stevens', '8835153', '0000-00-00', '666060HY ', '54-1793149', '526'),
('85-7613819', 'Christina Porter', '8878997', '0000-00-00', '485731FX ', '02-7723689', '482'),
('85-8814473', 'Andrew Thomas', '5311039', '0000-00-00', '513411HD ', '02-7723689', '863'),
('86-0723406', 'Walter Fowler', '6446296', '0000-00-00', '076199PZ ', '85-8814473', '526'),
('86-8296653', 'Linda Sanders', '1944433', '0000-00-00', '987583RH ', '', '526'),
('90-6092315', 'Christopher Carroll', '2779668', '0000-00-00', '344137LC ', '01-1621895', '863'),
('97-5740333', 'Billy Martin', '3090407', '0000-00-00', '129014SG ', '', '609');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`Emp_ID`),
  ADD KEY `B_id` (`B_id`),
  ADD KEY `Mng_ID` (`Mng_ID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `employees`
--
ALTER TABLE `employees`
  ADD CONSTRAINT `employees_ibfk_1` FOREIGN KEY (`B_id`) REFERENCES `branches` (`Branch_ID`),
  ADD CONSTRAINT `employees_ibfk_2` FOREIGN KEY (`Mng_ID`) REFERENCES `employees` (`Emp_ID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
