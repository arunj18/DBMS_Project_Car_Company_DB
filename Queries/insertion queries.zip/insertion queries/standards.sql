-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 19, 2017 at 10:57 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `standards`
--

CREATE TABLE `standards` (
  `Std_No` varchar(10) NOT NULL,
  `CO_Prod` decimal(5,4) DEFAULT NULL,
  `SO2_Prod` decimal(5,4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `standards`
--

INSERT INTO `standards` (`Std_No`, `CO_Prod`, `SO2_Prod`) VALUES
('126232', '1.3800', '0.4230'),
('149128', '2.4000', '0.1090'),
('191120', '1.7300', '0.4350'),
('219120', '1.4900', '0.6750'),
('224095', '2.1000', '0.1150'),
('245240', '2.5000', '0.6800'),
('246987', '1.7200', '0.8260'),
('263993', '2.7900', '0.9200'),
('297053', '1.2900', '0.6320'),
('32511', '1.8100', '0.0260'),
('375300', '1.7300', '0.0170'),
('405156', '2.3900', '0.7000'),
('414118', '2.6600', '0.9370'),
('4815', '1.4300', '0.4990'),
('491927', '2.9300', '0.4470'),
('500989', '2.7500', '0.5400'),
('537650', '2.1700', '0.1460'),
('558911', '2.6400', '0.7680'),
('577599', '1.8600', '0.3650'),
('611369', '2.5900', '0.2140'),
('617567', '2.9400', '0.7390'),
('645904', '1.3400', '0.8050'),
('734672', '1.3500', '0.2450'),
('80396', '1.6900', '0.9080'),
('870877', '2.0400', '0.6420'),
('905395', '2.6600', '0.1980'),
('940716', '2.6500', '0.3950'),
('960866', '2.6900', '0.6270'),
('961323', '2.5300', '0.6250'),
('984892', '2.3700', '0.1180');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `standards`
--
ALTER TABLE `standards`
  ADD PRIMARY KEY (`Std_No`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
