-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 19, 2017 at 10:57 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `offers`
--

CREATE TABLE `offers` (
  `Offer_ID` varchar(15) NOT NULL,
  `Start_date` date DEFAULT NULL,
  `End_date` date DEFAULT NULL,
  `B_id` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `offers`
--

INSERT INTO `offers` (`Offer_ID`, `Start_date`, `End_date`, `B_id`) VALUES
('BOKHG-37', '0000-00-00', '2017-03-14', '841497AB '),
('BQHGN-61', '0000-00-00', '2010-09-02', '296248AY '),
('CMBEZ-42', '0000-00-00', '2012-04-21', '485731FX '),
('DQAIB-50', '0000-00-00', '2009-11-01', '762047KW '),
('DYJVA-65', '0000-00-00', '2011-03-08', '151970RQ '),
('EBVDQ-77', '0000-00-00', '2010-11-05', '159083EN '),
('EMP-DIS-01', '0000-00-00', '2019-12-12', '841497AB'),
('EPHCG-52', '0000-00-00', '2014-06-02', '129014SG '),
('FEPAB-72', '0000-00-00', '2010-09-12', '344137LC '),
('ILREJ-74', '0000-00-00', '2017-01-06', '513411HD '),
('IVMAL-71', '0000-00-00', '2010-06-07', '239897CT '),
('KMQIT-23', '0000-00-00', '2012-12-01', '848897IT '),
('KPCAH-35', '0000-00-00', '2008-12-13', '076199PZ '),
('KXTBD-27', '0000-00-00', '2015-07-27', '229485NX '),
('MLQNB-05', '0000-00-00', '2011-11-16', '597848HD '),
('NMPGC-25', '0000-00-00', '2015-11-21', '649859NJ '),
('NWLPD-03', '0000-00-00', '2016-01-04', '144872OS '),
('OCFXQ-02', '0000-00-00', '2008-12-04', '081730GV '),
('PIUDT-29', '0000-00-00', '2009-01-13', '597388RE '),
('PJNOV-07', '0000-00-00', '2016-07-12', '054758ZL '),
('QDECI-51', '0000-00-00', '2011-02-27', '446747ZH '),
('QWSIG-28', '0000-00-00', '2010-01-13', '987583RH '),
('TGBAL-80', '0000-00-00', '2012-03-11', '580353QC '),
('UILZD-88', '0000-00-00', '2010-01-13', '349010QS '),
('UMHLN-93', '0000-00-00', '2016-07-14', '722184CJ '),
('VBMAW-65', '0000-00-00', '2014-11-25', '424680QU '),
('VJSFC-15', '0000-00-00', '2015-02-06', '086456BX '),
('VSLEK-62', '0000-00-00', '2012-09-17', '666060HY '),
('XZLHK-80', '0000-00-00', '2013-08-22', '266610GR '),
('YHETS-08', '0000-00-00', '2013-06-08', '857305RI '),
('ZLGWY-90', '0000-00-00', '2013-09-25', '217070XS ');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `offers`
--
ALTER TABLE `offers`
  ADD PRIMARY KEY (`Offer_ID`),
  ADD KEY `B_id` (`B_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `offers`
--
ALTER TABLE `offers`
  ADD CONSTRAINT `offers_ibfk_1` FOREIGN KEY (`B_id`) REFERENCES `branches` (`Branch_ID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
